#!/usr/bin/env python -*- coding: utf-8 -*-

from ressource.diary import *   #import du module diary contenat toutes les fonctions.

print('[INFO] Bienvenue dans votre agenda ...') #Phrase de bienvenue de l'agenda.

stay = 'o' #variable pour garder le script ouvert.

while stay == 'o' or stay == 'O':      #tant que l'utilisateur veut rester le script reste ouvert.

    #affichage des différentes options.
    print('[1] Voir agenda')
    print('[2] Supprimer un évènement')
    print('[3] Ajouter un évènement')
    print('[4] Quitter')

    #demande à l'utilisateur ce qu'il veut faire.
    choice = int(input('[INFO] Veuillez choisir une des possibilitées ci-dessus: '))

    #en fonction du choix on fait une action.
    if (choice == 1):
        print('[INFO] Voir agenda...')
        showDiary()
        stay = input("[INFO] Continuez ? [o]/[n]")
    elif (choice == 2):
        print('[INFO] Supprimer un évènement...')
        delEventDiary()
        stay = input("[INFO] Continuez ? [o]/[n]")
    elif (choice == 3):
        print('[INFO] Ajouter un évènement...')
        addEventDiary()
        stay = input("[INFO] Continuez ? [o]/[n]")
    elif (choice == 4):
        print('[INFO] Quitter...')
        stay = 'n'
    else:
        print('[!] Merci de faire un choix valide [!]')
        quit(0)