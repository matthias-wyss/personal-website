#!/usr/bin/env python -*- coding: utf-8 -*-

def showDiary():        #on ouvre l'agenda et on l'affiche à l'utilisateur.
    print('[AGENDA] Voici ce qui est prévu pour votre agenda.')
    f = open('Diary.txt', 'r')
    line = f.readline()
    cnt = 0
    while line:
        print("[{}] {}".format(cnt, line.replace(':', ' pour le ').strip()))
        line = f.readline()
        cnt += 1
    f.close()

def addEventDiary():    #on ajoute à l'agenda un évènement.

    eventName = input('[AGENDA] Écrivez votre tâche: ')
    eventDate = input('[AGENDA] Écrivez votre date (jj/mm/aaaa): ')
    event = eventName + ':' + eventDate
    print(event)
    f = open('Diary.txt', 'a')
    f.write(event + '\n')
    f.close()
    print('[AGENDA] Évènement ajouté avec succès.')

def delEventDiary():    #on supprime de l'agenda un évènement.
    diary = []
    f = open('Diary.txt', 'r')
    line = f.readline()
    cnt = 0
    while line:
        print("[{}] {}".format(cnt, line.replace(':', ' pour le ').strip()))
        diary.append(line)
        line = f.readline()
        cnt += 1
    f.close()
    num = int(input("[AGENDA] Entrez le numéro de l'évènement à supprimer :"))
    diary.pop(num)
    print('[AGENDA] Évènement supprimé avec succès.')
    f = open("Diary.txt", 'w')
    for i in diary:
        f.write(i)
    f.close()
    print("[AGENDA] Mise à jour de l'agenda réussite.")