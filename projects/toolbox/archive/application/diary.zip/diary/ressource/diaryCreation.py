event1 = ['Faire mes devoirs', "18/04/2020"]
event2 = ['Faire mon agenda', '04/04/2020']
event3 = ['Faire mes course', "18/04/2020"]
event4 = ["Boire de l'eau", '04/04/2020']
event5 = ['Acheter des vêtements', "18/04/2020"]
event6 = ['Courrir', '04/04/2020']
event7 = ['Travailler', "18/04/2020"]
event8 = ['Manger', '04/04/2020']


globalEvent = [event1, event2, event3, event4, event5, event6, event7, event8]

def createDiary():
    f = open("firstDiray.txt", 'w')
    for i in globalEvent:
        f.write(i[0] + ':' + i[1] + '\n')
    f.close()

createDiary()

